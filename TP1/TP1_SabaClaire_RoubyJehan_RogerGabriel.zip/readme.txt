# TP1 d'Intelligence Artificielle pour le jeux vidéo #

Claire Saba - SABC14529902
Jehan Rouby - ROUJ06070007
Gabriel Roger - ROGG15040006


Pour ouvrir le programme, ouvrer avec Visual Studio la solution (nous avons utilisé Visual Studio 2019) :
"Buckland_Chapter2-State Machines\WestWorldWithMessaging\WestWorldWithMessaging.sln"
Appuyer sur le boutton "Débogueur Windows Local" pour lancer l'éxécution.

Nous avons fait un compte-rendu "Compte Rendu TP 1.pdf" dans lequel ce trouve les diagrammes ainsi que la 
déscription des changements que nous avons apporté au code.

Nous n'avons pas rencontré de grande difficulté lors de l'implémentation. Cependant, après avoir implémenté 
les threads, certains dialogues des agents et messages s'entremèlent ou ne sont pas de la bonne couleur.