#ifndef LOCATIONS_H
#define LOCATIONS_H


enum location_type
{
	shack,
	goldmine,
	bank,
	saloon
};




//uncomment this to send the output to a text file
//#define TEXTOUTPUT




#endif